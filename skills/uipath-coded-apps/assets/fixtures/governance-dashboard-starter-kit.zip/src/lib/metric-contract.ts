// The data-fetch signature every metric module exports for the MAIN widget.
//
// sdk is `any` because the SDK service constructors take `sdk as never`; the
// array return preserves the settled Promise<any[]> harness — SDK response
// interfaces lack implicit index signatures and are not assignable to
// Record<string, unknown>[], so any[] accepts SDK-typed arrays directly while
// still requiring an array return. Main widgets render an array, so `fetchData`
// stays strictly `Promise<any[]>` (detail fetches use MetricResult — see below).
export type MetricFn = (sdk: any, getToken: () => Promise<string>) => Promise<any[]>

// What a DETAIL fetch may return: a bare array (single detail table) OR a
// named-source map for a RICH detail view — one fetch yields several named
// series (e.g. `{ rows, byHook, byStandard }`) and each `detailView` sub-widget
// reads `data[source]`. The generated detail view normalizes an array to `{ rows }`.
export type MetricResult = any[] | NamedSourceMap

/** A single dynamic data row — the canonical shape for widget + detail data. */
export type Row = Record<string, unknown>

/** Named-source map for rich detail views: each key feeds one detailView sub-widget
 *  (e.g. { rows, byHook, byStandard }). Values stay `any[]` so SDK-typed arrays
 *  remain assignable without casts (same seam rationale as MetricFn). */
export type NamedSourceMap = Record<string, any[]>

/** One line/series in a multi-series chart (key = data field, color = CSS var). */
export interface ChartSeriesDef { key: string; color: string }

// Record-grain chart drill-down (`detail: true`): `export const fetchDetail: MetricDetailFn`.
// Return an array for a single table, or a named-source map for a rich detailView.
export type MetricDetailFn = (sdk: any, getToken: () => Promise<string>) => Promise<MetricResult>

// The keyed-detail signature for row-click drill-downs. A table widget with a
// `rowLink` exports this so "click THIS row → fetch THAT entity's records"
// (e.g. fetchDetailByKey(sdk, agentName) → that agent's most recent trace spans).
// Returns an array (single detail table) or a named-source map (rich detail view).
// `key` is the clicked row's link field value (route param).
export type MetricDetailByKeyFn = (sdk: any, key: string, getToken: () => Promise<string>) => Promise<MetricResult>
