# Queues

A queue holds work items. Failed items are retried.
